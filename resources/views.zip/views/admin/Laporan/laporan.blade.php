@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <h1>Laporan</h1>

        <div class="card">
            <div class="card-body">
                <div class="d-flex">
                    <div class="row input-daterange mb-4">
                        <div class="col"><input class="form-control" type="text" placeholder="From Date" readonly style="cursor: pointer"></div>
                        <div class="col"><input class="form-control" type="text" placeholder="To Date" readonly style="cursor: pointer"></div>
                        <div class="col"><button class="btn btn-primary mr-3">Filter</button><button class="btn btn-secondary"> Reset</button></div>
                    </div>
                </div>
                <table id="TLapor" class="table table-bordered">
                    <thead>
                        <tr>
                            <th>NIK</th>
                            <th>Tanggal Pengaduan</th>
                            <th>Tipe</th>
                            <th>Isi Laporan</th>
                            <th>Foto</th>
                            <th>Status</th>
                            <th>Tgl Tanggapan</th>
                            <th>Tanggapan</th>
                            <th>Nama Petugas</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>

    </div>

<script>
    $(document).ready(function() {
        $('.input-daterange').datepicker({
            todayBTN: 'linked',
            format: 'yyyy-mm-dd',
            autoclose: true,
        });
        $('#TLapor').DataTable({
            responsive: true,
            "autoWidth": false,
            scrollX: true,
            dom: 'Bfrtip',
            buttons: [
                'print'
            ]
        });
    });
</script>
@endsection