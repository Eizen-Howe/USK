@extends('layouts.app')

@section('content')
    <div class="container mt-4">
        <h1>Masyarakat</h1>

        <div class="card">
            <div class="card-header pb-0">
                <p class="">List Masyarakat</p>
            </div>
            <div class="card-body">
                <table id="TMasyarakat" class="table table-bordered table-striped text-center">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>Erwin Rommel</td>
                            <td>0031258486</td>
                            <td>
                                <a href="/detailmasyarakat" class="btn btn-primary" style="min-width: 120px;"><i class="fas fa-search"></i> Detail</a>
                                <a href="" class="btn btn-danger" style="min-width: 120px;"><i class="fas fa-trash-alt"> Hapus</i></a>
                            </td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Heinrich Himmler</td>
                            <td>0031258789</td>
                            <td>
                                <a href="/detailmasyarakat" class="btn btn-primary" style="min-width: 120px;"><i class="fas fa-search"></i> Detail</a>
                                <a href="" class="btn btn-danger" style="min-width: 120px;"><i class="fas fa-trash-alt"> Hapus</i></a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{-- script --}}
    <script>
      $(function () {
        $("#TMasyarakat").DataTable({
          responsive: true,
          "autoWidth": false,
        });
      });
    </script>
@endsection
