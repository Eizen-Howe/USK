@extends('layouts.app')

@section('content')
    <div class="container mt-4 text-center">
        <h1>Selamat Datang {{ Auth::user()->name }}, di Aplikasi Pelaporan Pengaduan Masyarakat</h1>

        <div class="row px-5 justify-content-center">
            <div class="col-lg-3">
                <a href="/masyarakat" class="text-decoration-none text-reset">
                    <div class="card text-white" style="background-color: #ff8552">
                        <div class="card-body text-center">
                            <span><i class="fas fa-users fa-7x color-white"></i></span>
                            <h3>Pengguna</h3>
                            <h3>{{ $user }}</h3>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="/pengaduan" class="text-decoration-none text-reset">
                    <div class="card text-white bg-success">
                        <div class="card-body text-center">
                            <span><i class="fas fa-check fa-7x color-white"></i></span>
                            <h3>Cek Laporan</h3>
                            <h3>{{ $pengaduan }}</h3>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-3">
                <a href="/petugas" class="text-decoration-none text-reset">
                    <div class="card text-white" style="background-color: #ff8552">
                        <div class="card-body text-center">
                            <span><i class="fas fa-users fa-7x color-white"></i></span>
                            <h3>Petugas</h3>
                            <h3>{{$petugas}}</h3>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row mt-4">
            <div class="col">
                <table class="table table-striped table-bordered">
                    <thead class="bg-secondary text-white">
                        <tr>
                            <th>Keterangan</th>
                            <th>Tabel</th>
                            <th>Data</th>
                            <th>User</th>
                            <th>Tanggal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Tambah</td>
                            <td>Petugas</td>
                            <td>Erwin</td>
                            <td>Admin</td>
                            <td>2021-03-03</td>
                        </tr>
                        <tr>
                            <td>Tambah</td>
                            <td>Petugas</td>
                            <td>Erwin</td>
                            <td>Admin</td>
                            <td>2021-03-03</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection